#command to build -> mvn package -DskipTests=true
# schema mismatch issue -> https://kb.databricks.com/data/wrong-schema-in-files.html