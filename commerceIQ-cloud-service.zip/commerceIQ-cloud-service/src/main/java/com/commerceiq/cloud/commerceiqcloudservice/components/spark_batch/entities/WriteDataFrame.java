package com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.entities;

import org.apache.spark.SparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;
import org.javatuples.Pair;

@FunctionalInterface
public interface WriteDataFrame {
    void write(Dataset<Row> dataframe, Pair<SparkContext, SparkSession> spark, Object... payloads);
}
