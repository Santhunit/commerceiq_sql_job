package com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.beans;

import com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.entities.DataFrameCallback;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.SparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.javatuples.Pair;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Configuration
public class SQLBeans {

    @Bean("sqlOnDF")
    public DataFrameCallback<Dataset<Row>> sqlOnDF(){
        return (spark, dataframe, params, payloads) -> {
            String sql = (String) payloads[0];
            Dataset<Row> resultDF = spark.getValue1().sql(sql);
            return resultDF;
        };
    }

}
