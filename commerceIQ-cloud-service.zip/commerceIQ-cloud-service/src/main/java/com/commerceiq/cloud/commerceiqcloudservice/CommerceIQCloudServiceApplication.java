package com.commerceiq.cloud.commerceiqcloudservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication(scanBasePackages = "com.commerceiq")
@EnableAutoConfiguration(exclude = {org.springframework.boot.autoconfigure.gson.GsonAutoConfiguration.class})
public class CommerceIQCloudServiceApplication {
	public static void main(String[] args) {
		SpringApplication.run(CommerceIQCloudServiceApplication.class, args);
	}
}
