package com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch;

import com.beust.jcommander.Parameter;
import com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.enums.DeployMode;
import com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.enums.enumConverter.DeployModeConverter;
import lombok.Data;

@Data
public class GenericBatchJobArgs {
    @Parameter(names = "appName", description = "Spark App Name")
    private String appName;

    @Parameter(names = "deployMode", description = "Spark Job Deploy Mode", converter = DeployModeConverter.class)
    private DeployMode deployMode;
}
