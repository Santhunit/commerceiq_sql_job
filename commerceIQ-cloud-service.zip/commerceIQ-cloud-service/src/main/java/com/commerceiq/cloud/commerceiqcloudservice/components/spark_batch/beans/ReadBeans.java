package com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.beans;

import com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.entities.ReadDataFrame;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ReadBeans {

    @Bean("s3ReadDF")
    public ReadDataFrame getSourceDF(){
        return (spark, jobSourceVO) -> {
            Dataset<Row> df = null ;
            switch (jobSourceVO.getFileType().toLowerCase()){ 
                case "json":
                    df = spark.getValue1().read().json(jobSourceVO.getUrlList().toArray(new String[0]));
                    break;
                case "parquet":
                    df = spark.getValue1().read().parquet(jobSourceVO.getUrlList().toArray(new String[0]));
            }

            if(StringUtils.isNotEmpty(jobSourceVO.getTempView()))
                df.createOrReplaceTempView(jobSourceVO.getTempView()) ;
            return df;
        };
    }





}
