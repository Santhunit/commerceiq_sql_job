package com.commerceiq.cloud.commerceiqcloudservice.spark_batch.request.v0;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class JobSourceVO {

    private String url ;
    private String tempView ;
    private String fileType ;
    private List<String> urlList;

    public void setUrl(String url){
        this.url = url;
        this.urlList = new ArrayList<String>();
        for(String individualUrl: this.url.split(",")){
        	//TODO: can manage multiple clients as well based on params.
            this.urlList.add("s3://" + individualUrl);
        }
    }

}
