package com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.beans;

import com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.entities.SparkSessionInit;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.sql.SparkSession;
import org.javatuples.Pair;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;
import java.util.Map;


@Configuration
public class SparkInitBeans {

    @Bean("defaultSparkInit")
    public SparkSessionInit initSparkSession(){
        return new SparkSessionInit() {
            @Override
            public Pair<SparkContext, SparkSession> initSparkSession(List<String> clients, Map<String, String> params, String appName) {
                SparkConf conf = new SparkConf().setAppName(appName);
                conf.set("spark.sql.caseSensitive","true");
                conf.set("spark.sql.parquet.mergeSchema", "true") ;
                SparkContext sc = new SparkContext(conf);
                /*
                 *  TODO: pass the credentials as per client specific  or set in EMR cluster mode core-site.xml file.
                */
//              sc.hadoopConfiguration().set("fs.s3a.access.key", "AKIAYTOQPIZKBCR3BMWY");
//              sc.hadoopConfiguration().set("fs.s3a.secret.key", "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");
//              sc.hadoopConfiguration().set("fs.s3.awsAccessKeyId", "AKIAYTOQPIZKBCR3BMWY");
//              sc.hadoopConfiguration().set("fs.s3.awsSecretAccessKey", "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");
//              sc.hadoopConfiguration().set("fs.s3a.fast.upload", "true");
                return new Pair<>(sc, new SparkSession(sc));
            }
        };
    }
}
