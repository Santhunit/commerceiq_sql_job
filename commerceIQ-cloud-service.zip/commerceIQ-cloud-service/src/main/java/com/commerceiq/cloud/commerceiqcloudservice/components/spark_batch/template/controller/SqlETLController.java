package com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.template.controller;

import com.beust.jcommander.DynamicParameter;
import com.beust.jcommander.Parameters;
import com.maddenabbott.jcommander.controller.Command;
import com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.template.driver.SqlEtlDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
 
@Component
@Parameters(commandNames = "SqlETL", separators = "=")
public class SqlETLController implements Command {
    @DynamicParameter(names = "-P", description = "Dynamic parameters go here")
    private Map<String, String> params = new HashMap<>();
    
    @Autowired
    private SqlEtlDriver sqlEtlDriver;
    
    private static final Logger LOGGER = LoggerFactory.getLogger(SqlETLController.class);
    @Override
    public void run() throws Exception {
        LOGGER.info("params SqlETLController {}", params);  
        sqlEtlDriver.driveJob(params, null);
    }
}
