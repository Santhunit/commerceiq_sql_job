package com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.enums;

import lombok.Getter;
import org.apache.spark.sql.SaveMode;

import java.util.HashMap;
import java.util.Map;


@Getter
public enum SaveModeEnum {

    APPEND("append", SaveMode.Append),
    OVERWRITE("overwrite", SaveMode.Overwrite);

    private String type;
    private SaveMode saveMode;

    SaveModeEnum(String type, SaveMode saveMode) {
        this.type = type;
        this.saveMode = saveMode;
    }

    public static final Map<String, SaveModeEnum> SAVE_MODE_MAP = new HashMap<>(); 
    static{
        for(SaveModeEnum saveMode : SaveModeEnum.values()){
            SAVE_MODE_MAP.put(saveMode.getType(), saveMode) ;
        }
    } 
    public static SaveModeEnum getEnumByType(String type){
        return SAVE_MODE_MAP.get(type.toLowerCase());
    } 
}
