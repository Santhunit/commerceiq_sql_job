package com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.enums;

import java.util.HashMap;
import java.util.Map;

public enum WritePartitionDateFieldFormatEnum {

    SECOND("sec"),

    DATE_STRING("string"),

    MILLI_SECOND("msec") ;

    private String value ;

    WritePartitionDateFieldFormatEnum(String value) {
        this.value = value;
    }

    public static final Map<String, WritePartitionDateFieldFormatEnum> WRITE_PARTITION_DATE_FIELD_ENUM_MAP = new HashMap<>() ;

    static{
        for(WritePartitionDateFieldFormatEnum writePartitionDateFieldFormatEnum :  WritePartitionDateFieldFormatEnum.values()){
            WRITE_PARTITION_DATE_FIELD_ENUM_MAP.put(writePartitionDateFieldFormatEnum.value, writePartitionDateFieldFormatEnum) ;
        }
    }

    public static WritePartitionDateFieldFormatEnum getEnumByValue(String value){
        return WRITE_PARTITION_DATE_FIELD_ENUM_MAP.get(value) ;
    }
}
