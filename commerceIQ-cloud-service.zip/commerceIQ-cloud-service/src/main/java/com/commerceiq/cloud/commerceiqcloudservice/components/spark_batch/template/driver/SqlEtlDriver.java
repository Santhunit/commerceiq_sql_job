package com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.template.driver;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.GenericBatchJobArgs;
import com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.entities.DataFrameCallback;
import com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.entities.ReadDataFrame;
import com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.entities.WriteDataFrame;
import com.commerceiq.cloud.commerceiqcloudservice.spark_batch.request.v0.JobSourceVO;

import org.apache.spark.SparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.javatuples.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class SqlEtlDriver extends DefaultSparkJob {

    @Autowired
    @Qualifier("s3ReadDF")
    ReadDataFrame s3ReadDF;
 
    @Autowired
    @Qualifier("sqlOnDF")
    DataFrameCallback<Dataset<Row>> sqlOnDF;
 
    @Autowired
    @Qualifier("s3WriteDF")
    WriteDataFrame s3WriteDF;

    private static final Logger LOGGER = LoggerFactory.getLogger(SqlEtlDriver.class);

    @Override
    protected void jobImplementation(Map<String, String> params, GenericBatchJobArgs jobArgs, Pair<SparkContext, SparkSession> spark) throws Exception {
        try {
            JobSourceVO[] jobSourceVOS = new ObjectMapper().readValue(params.get("src"), JobSourceVO[].class);
            for(JobSourceVO jobSourceVO : jobSourceVOS){
                s3ReadDF.readDataFrame(spark, jobSourceVO);
            }

            Dataset<Row> resultdf = sqlOnDF.onDataFrame(spark, null, params, params.get("sql")) ;
            // do the business logic as per enrich/job after the query and map to output object. 
            resultdf.persist(StorageLevel.MEMORY_AND_DISK());
            s3WriteDF.write(resultdf, spark, params);
        }catch (Exception e){
            LOGGER.error("exception in SqlEtlDriver, ", e);
            throw new Exception("exception in SqlEtlDriver") ;
        }
    }
}