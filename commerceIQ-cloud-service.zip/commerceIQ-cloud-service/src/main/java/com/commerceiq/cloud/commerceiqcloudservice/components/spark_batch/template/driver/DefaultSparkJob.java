package com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.template.driver;

import com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.GenericBatchJobArgs;
import com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.entities.SparkDriver;
import com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.entities.SparkSessionInit;
import org.apache.spark.SparkContext;
import org.apache.spark.sql.SparkSession;
import org.javatuples.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Map;

@Component
public abstract class DefaultSparkJob implements SparkDriver {

    @Autowired
    @Qualifier("defaultSparkInit")
    SparkSessionInit initSparkSession;

    @Override
    public void driveJob(Map<String, String> params, GenericBatchJobArgs jobArgs) throws Exception{
        Pair<SparkContext, SparkSession> spark = initSparkSession.initSparkSession(null, null, params.get("appName"));
        jobImplementation(params, jobArgs, spark);
        spark.getValue1().stop();
        spark.getValue0().stop();
    }

    protected abstract void jobImplementation(Map<String, String> params, GenericBatchJobArgs jobArgs, Pair<SparkContext, SparkSession> spark) throws Exception;
}
