package com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.enums;


public enum FileType { 
    JSON("json"),
    PARQUET("parquet"); 
    private String fileType;

    FileType(String fileType) {
        this.fileType = fileType;
    }
}
