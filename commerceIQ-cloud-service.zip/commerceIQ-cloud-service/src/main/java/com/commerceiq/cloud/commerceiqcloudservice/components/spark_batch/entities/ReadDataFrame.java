package com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.entities;

import com.commerceiq.cloud.commerceiqcloudservice.spark_batch.request.v0.JobSourceVO;
import org.apache.spark.SparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.javatuples.Pair;

@FunctionalInterface
public interface ReadDataFrame {
    Dataset<Row> readDataFrame(Pair<SparkContext, SparkSession> spark, JobSourceVO jobSourceVO);
}
