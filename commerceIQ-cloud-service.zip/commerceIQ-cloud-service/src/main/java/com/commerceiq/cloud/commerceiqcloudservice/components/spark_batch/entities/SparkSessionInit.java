package com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.entities;

import org.apache.spark.SparkContext;
import org.apache.spark.sql.SparkSession;
import org.javatuples.Pair;

import java.util.List;
import java.util.Map;

public interface SparkSessionInit {
    Pair<SparkContext,SparkSession> initSparkSession(List<String> clients, Map<String, String> configs, String appName);
}
