package com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.entities;

import com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.GenericBatchJobArgs;
import java.util.Map; 

public interface SparkDriver {
    void driveJob(Map<String, String> params, GenericBatchJobArgs jobArgs) throws Exception;
}
