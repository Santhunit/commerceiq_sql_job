package com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.entities;

import org.apache.spark.SparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.javatuples.Pair;

import java.util.Map;

@FunctionalInterface
public interface DataFrameCallback<T> {
    T onDataFrame(Pair<SparkContext, SparkSession> spark, Dataset<Row> dataframe, Map<String, String> params, Object... payloads);
}
 