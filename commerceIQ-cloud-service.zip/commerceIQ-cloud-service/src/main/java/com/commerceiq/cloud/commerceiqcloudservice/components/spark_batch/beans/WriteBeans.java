package com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.beans;

import com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.entities.WriteDataFrame;
import com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.enums.SaveModeEnum;
import com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.enums.WritePartitionDateFieldFormatEnum;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.sql.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Configuration
public class WriteBeans {

    @Bean("s3WriteDF")
    public WriteDataFrame writeDF(){
        return (dataframe, spark, payloads) -> {
            Map<String, String> params = (Map<String, String>) payloads[0];
            String destinationPath = "s3://" + params.get("dest");
            String fileType = params.get("destFileType");
            DataFrameWriter<Row> dataFrameWriter;
            SaveMode saveMode = SaveMode.Overwrite;
            if(params.get("saveMode")!=null && SaveModeEnum.getEnumByType(params.get("saveMode"))!=null){
                saveMode = SaveModeEnum.getEnumByType(params.get("saveMode")).getSaveMode();
            }
            if(StringUtils.isNotEmpty(params.get("isWritePartitioned")) &&
                    Boolean.parseBoolean(params.get("isWritePartitioned")) &&
                    StringUtils.isNotEmpty(params.get("writePartitionDateField"))) {
                Column column = null;
                WritePartitionDateFieldFormatEnum writePartitionDateFieldFormatEnum = WritePartitionDateFieldFormatEnum.getEnumByValue(params.get("writePartitionDateFieldFormat"));
                if(writePartitionDateFieldFormatEnum == null){
                    column = dataframe.col(params.get("writePartitionDateField"));
                } else if(writePartitionDateFieldFormatEnum == WritePartitionDateFieldFormatEnum.MILLI_SECOND){
                    column = dataframe.col(params.get("writePartitionDateField")).divide(1000);
                } else if (writePartitionDateFieldFormatEnum == WritePartitionDateFieldFormatEnum.DATE_STRING &&
                        StringUtils.isNotEmpty(params.get("writePartitionDateFieldStringFormat"))) {
                    column = functions.to_timestamp(dataframe.col(params.get("writePartitionDateField")), params.get("writePartitionDateFieldStringFormat")).cast("long");

                } else {
                    column = dataframe.col(params.get("writePartitionDateField"));
                }

                dataframe = dataframe
                        .withColumn("year", functions.from_unixtime(column, "yyyy"))
                        .withColumn("month", functions.from_unixtime(column, "MM")) ;

                List<String> partitionColumnNames = new ArrayList<>() ;
                partitionColumnNames.add("year") ;
                partitionColumnNames.add("month") ;

                if(StringUtils.isNotEmpty(params.get("isDayPartition")) &&
                        Boolean.parseBoolean(params.get("isDayPartition"))){
                    dataframe = dataframe.withColumn("day",functions.from_unixtime(column, "dd") ) ;
                    partitionColumnNames.add("day") ;
                }

                dataFrameWriter = dataframe
                        .write()
                        .partitionBy(partitionColumnNames.toArray(new String[0]))
                        .mode(saveMode);

                if(saveMode == SaveMode.Overwrite){
                    dataFrameWriter.option("spark.sql.sources.partitionOverwriteMode", "static") ;
                }
            } else {
                dataFrameWriter = dataframe.write().mode(saveMode);
            }

            switch (fileType.toLowerCase()){
                case "json":
                    if(params.get("writeCompression")!=null && params.get("writeCompression").equalsIgnoreCase("gzip")){
                        dataFrameWriter.option("compression", "gzip").json(destinationPath);
                    }else{
                        dataFrameWriter.json(destinationPath);
                    }
                    break;
                case "parquet":
                    dataFrameWriter.parquet(destinationPath);
                    break;
            }
        };
    }

}
