package com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.enums.enumConverter;

import com.beust.jcommander.IStringConverter;
import com.beust.jcommander.ParameterException;
import com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.enums.DeployMode;


public class DeployModeConverter implements IStringConverter<DeployMode> {

    @Override
    public DeployMode convert(String mode) {
        DeployMode deployMode = DeployMode.fromString(mode);
        if(deployMode == null) {
            throw new ParameterException("Invalid Deploy Mode");
        }
        return deployMode;
    }
}
