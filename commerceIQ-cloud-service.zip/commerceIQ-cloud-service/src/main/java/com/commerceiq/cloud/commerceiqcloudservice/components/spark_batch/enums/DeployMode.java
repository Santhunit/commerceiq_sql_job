package com.commerceiq.cloud.commerceiqcloudservice.components.spark_batch.enums;
public enum DeployMode {

    LOCAL("local");

    private String mode;

    // converter that will be used later
    public static DeployMode fromString(String code) {
        for(DeployMode deployMode : DeployMode.values()) {
            if(deployMode.toString().equalsIgnoreCase(code)) {
                return deployMode;
            }
        }
        return null;
    }

    DeployMode(String mode) {
        this.mode = mode;

    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

}
